from .sos import morse_code

__all__ = [morse_code]