# ft_package

A sample test package for learning Python packaging.

## Installation

```bash
pip install ./dist/ft_package-0.0.1-py3-none-any.whl
# ou
pip install ./dist/ft_package-0.0.1.tar.gz